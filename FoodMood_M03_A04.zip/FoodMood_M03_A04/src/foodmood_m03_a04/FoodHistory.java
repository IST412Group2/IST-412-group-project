/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package foodmood_m03_a04;

/**
 *
 * @author Matt
 */
import java.util.ArrayList;
import java.util.Date;

public class FoodHistory {
    private ArrayList<Food> listOfFoods;
    private ArrayList<Date> listOfDatesEaten;
    
    public FoodHistory() {
        listOfFoods = new ArrayList<Food>();
        listOfDatesEaten = new ArrayList<Date>();
    }
    
    public void addFood(Food food) {
        listOfFoods.add(food);
        listOfDatesEaten.add(new Date());
    }
    public ArrayList<Food> getFoods() {
        return listOfFoods;
    }
    public ArrayList<Date> getDatesEaten() {
        return listOfDatesEaten;
    }
}