/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package foodmood_m03_a04;

/**
 *
 * @author Matt
 */

import com.sun.javafx.binding.Logging;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import static java.lang.Double.parseDouble;
import java.net.URL;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import java.util.Iterator;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;

public class FoodController implements Initializable {
    private Food fd;
    private FoodHistory fh;
    
    @FXML
    private Label enterFoodLabel;
    @FXML
    private Label enterAmountLabel;
    @FXML
    private TextField enterFoodField;
    @FXML
    private TextField enterAmountField;
    @FXML
    private Label attentionLabel;
    @FXML
    private DatePicker dp;
    @FXML
    private Label showDateLabel;

    
    /**
     * Initializes the controller class.
     * @param url The location to resolve relative paths of resources.
     * @param rb The resources to be used by this controller.
     */
   
    @Override
    public void initialize(URL url, ResourceBundle rb) {
    }    
    
    public void handleBack(ActionEvent event) throws IOException{
        FoodMood_M03_A04.scene.setRoot(FXMLLoader.load(getClass().getResource("Nav.fxml")));
    }
    
    public void handleNext(ActionEvent event) throws IOException{
        try{
            //FoodMood_M03_A04.scene.setRoot(FXMLLoader.load(getClass().getResource("Mood.fxml")));
            attentionLabel.setVisible(true);
            //double amount = parseDouble(enterAmountField.getText());
            fd = new Food(enterFoodField.getText(), parseDouble(enterAmountField.getText()));
            fh.addFood(fd);
            
        }
        catch(java.lang.NullPointerException exception){
            System.out.println(exception.getCause());
        }
        catch (Throwable exception)
        {
             //Catch other Throwables.
            System.out.println(exception.getCause());
        }
    }
    
    public void pickDate(ActionEvent event){
        try{
            LocalDate ld = dp.getValue();
            showDateLabel.setText(ld.toString());
            fh.addDate(ld);
        }
        catch(java.lang.NullPointerException exception){
            System.out.println(exception.getCause());
        }
        catch (Throwable exception)
        {
             //Catch other Throwables.
            System.out.println(exception.getCause());
        }
    }
}
